<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>KODEIN</title>

    <!-- google fonts -->
    <link href="//fonts.googleapis.com/css2?family=Jost:wght@300;400;600&display=swap" rel="stylesheet">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style-starter.css')); ?>">
</head>

<body>
    <!-- header -->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg stroke">
                <a class="navbar-brand" href="index.html">
                    Kodein.
                </a>
                <!-- if logo is image enable this
      <a class="navbar-brand" href="#index.html">
          <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
      </a> -->
                <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
                    data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                    </span>
                </button>

                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item @about__active">
                            <a class="nav-link" href="about.html">Test</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-primary btn-style" href="https://kodein.sch.id/"> Login </a>
                        </li>
                    </ul>
                </div>
                <!-- toggle switch for light and dark theme -->
                
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>
    <!-- //header -->

    <!-- banner section -->
    <section id="home" class="w3l-banner py-10">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-sm-12 mt-lg-0 mt-4">
                    <h1 class="mb-2 title"> <span>Segera</span> Daftarkan <span>Putra Anda! Kuota </span> Terbatas!</h1>
                    <p class="sub">Kodein - Sekolah Developer Indonesia adalah sekolah yangmencetak full stack developer
                        dan software engineer siap pakai. Dengan metode pembelajaran praktek di inkubator (PT
                        Kodeintekno) dan di supervisi dengan mentor-mentor yang sudah berpengalaman selama 10 tahun.
                        Jadi tunggu apalagi, segera daftarkan sekarang juga. Untuk informasi lebih lanjut klik link
                        dibawah</p>
                    <div class="mt-sm-5 mt-4 tombol">
                        <a class="btn btn-primary btn-style mr-2" href="contact.html"> Mulai Test </a>
                        <a class="btn btn-outline-primary btn-style mr-2" href="https://kodein.sch.id/"> Link </a>
                    </div>
                </div>
                <div class="col-lg-6 mt-4">
                    <div class="position-relative">
                        <img src="<?php echo e(asset('images/image1.jpg')); ?>" alt="myphoto" class="radius-image img-fluid gambar">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //banner section -->

    <!-- home page about section -->
    <section class="w3l-index3" id="about">
        <div class="midd-w3 py-5">
            <div class="container py-lg-5 py-md-3">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="position-relative">
                            <img src="<?php echo e(asset('images/image2.jpg')); ?>" alt="" class="radius-image img-fluid title">
                        </div>
                    </div>
                    <div class="col-lg-8 mt-4">
                        <h3 class="title-big sub">Profil Sekolah Developer Indonesia</h3>
                        <p class="mt-4 sub">Untuk melihat profil dari Kodein - Sekolah Developer Indonesia silahkan klik
                            link berikut: </p>
                        <div class="mt-sm-5 tombol">
                            <a class="btn btn-primary btn-style mr-2"
                                href="https://www.youtube.com/watch?v=a1-mJjGyqcA&t=6s&ab_channel=KODEINSekolahDeveloperIndonesia">Link</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //home page about section -->

    <!-- home page second section -->
    <div class="py-5 w3l-resume">
        <div class="container py-lg-5 py-3">
            <h1 class="text-center mb-2 sub">Galeri</h1>
            <hr class="mb-4">
            <div class="row mt-3">
                <div class="col-lg-6">
                    <div class="position-relative">
                        <img src="<?php echo e(asset('images/image3.jpg')); ?>" alt="" class="radius-image img-fluid title">
                    </div>
                </div>
                <div class="col-lg-6 mt-4">
                    <h3 class="title-big sub">Kodein Berbagi</h3>
                    <p class="mt-4 sub">Program KODEIN BERBAGI adalah sebuah kegiatan para siswa untuk berbagi
                        pengalaman & Ilmu ke lembaga lembaga pendidikan lainnya atau ke khalayak ramai baik di sekitar
                        sekolah ataupun yang lebih luas lagi.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- //home page second section -->

    <!-- home page services section -->
    <section class="w3l-services">
        <div class="blog py-5" id="services">
            <div class="container py-lg-5">
                <h5 class="title-small text-center">Activity</h5>
                <h3 class="title-big text-center mb-sm-5 mb-4">Activity In KODEIN</h3>
                <div class="row">
                    <div class="col-md-12 mx-auto pr-2">
                        <div class="owl-two owl-carousel owl-theme">
                            <div class="item">
                                <div class="card">
                                    <div class="box-wrap">
                                        <div class="position-relative mb-4">
                                            <img src="<?php echo e(asset('images/image4.jpg')); ?>" alt=""
                                                class="radius-image img-fluid">
                                        </div>
                                        
                                        <p>Kegiatan Siswa dalam belajar bersama - 17 May 2023</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card">
                                    <div class="box-wrap">
                                        <div class="position-relative mb-4">
                                            <img src="<?php echo e(asset('images/image5.jpg')); ?>" alt=""
                                                class="radius-image img-fluid">
                                        </div>
                                        
                                        <p>Kegiatan Siswa dalam belajar bersama - 17 May 2023</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card">
                                    <div class="box-wrap">
                                        <div class="position-relative mb-4">
                                            <img src="<?php echo e(asset('images/image3.jpg')); ?>" alt=""
                                                class="radius-image img-fluid">
                                        </div>
                                        
                                        <p>Kegiatan Siswa dalam belajar bersama - 17 May 2023</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="card">
                                    <div class="box-wrap">
                                        <div class="position-relative mb-4">
                                            <img src="<?php echo e(asset('images/image1.jpg')); ?>" alt=""
                                                class="radius-image img-fluid">
                                        </div>
                                        
                                        <p>Kegiatan Siswa dalam belajar bersama - 17 May 2023</p>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-5 text-more">
                    <p class="mt-4 pt-3 sample text-center">
                        <a href="services.html">View All Activity <span class="pl-2 fa fa-long-arrow-right"></span></a>
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- //home page services section -->

    <!-- testimonials -->
    <section class="w3l-clients" id="clients">
        <!-- /grids -->
        <div class="cusrtomer-layout py-5">
            <div class="container py-lg-5 py-md-4">
                <div class="heading text-center mx-auto">
                    <h3 class="title-big mb-md-5 mb-4">What Others Say </h3>
                </div>
                <!-- /grids -->
                <div class="testimonial-width">
                    <div id="owl-demo1" class="owl-carousel owl-theme mb-4">
                        <div class="item">
                            <div class="testimonial-content">
                                <div class="testimonial">
                                    <blockquote>
                                        <q>Kodein merupakan sekolah yang mempersiapkan siswa untuk bisa langsung siap
                                            kerja di dunia IT. Saya sarankan agar orang tua yang ingin anaknya siap
                                            kerja di insdustri IT menyekolahkan di KODEIN</q>
                                    </blockquote>
                                    <div class="testi-des">
                                        <div class="test-img"><img src="<?php echo e(asset('images/')); ?>" class="img-fluid"
                                                alt="">
                                        </div>
                                        <div class="peopl align-self">
                                            <h3>Wali Siswa Abdul Razak - angkatan 0</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /grids -->
        </div>
        <!-- //grids -->
    </section>
    <!-- //testimonials -->

    <!-- Footer -->
    <section class="w3l-footer py-sm-5 py-4">
        <div class="container">
            <div class="footer-content">
                <div class="row">
                    <div class="col-lg-8 footer-left">
                        <a href="#url" class="m-0">KODEIN</a>
                        <p>Harvest City Cluster Orchid A, Blok OA 12 No 18</p>
                        <p>© 2023 KODEIN. All Rights Reserved</p>
                    </div>
                    <div class="col-lg-4 footer-right text-lg-right text-center mt-lg-0 mt-3">
                        <ul class="social m-0 p-0">
                            <li><a href="https://www.facebook.com/people/Sekolah-Developer-Indonesia/100088412141036/"><span class="fa fa-facebook-official"></span></a></li>
                            
                            <li><a href="https://www.instagram.com/sekolahdeveloperindonesia/"><span class="fa fa-instagram"></span></a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- move top -->
        <button onclick="topFunction()" id="movetop" title="Go to top">
            <span class="fa fa-angle-up"></span>
        </button>
        <!-- /move top -->
    </section>

    <script src="https://unpkg.com/scrollreveal"></script>
    <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }

        const sr = ScrollReveal({
            origin: 'top',
            distance: '80px',
            duration: 2000,
            reset: true
        })

        sr.reveal('.gambar', {})
        sr.reveal('.title', {
            origin: 'left'
        })
        sr.reveal('.tombol', {
            delay: 200
        })
        sr.reveal('.sub', {})

    </script>
    <!-- //Footer -->

    <!-- all js scripts and files here -->

    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script><!-- default jQuery -->

    <!-- /typig-text-->
    <script>
        const typedTextSpan = document.querySelector(".typed-text");
        const cursorSpan = document.querySelector(".cursor");

        const textArray = ["UI/UX Designer", "Freelancer", "Web developer"];
        const typingDelay = 200;
        const erasingDelay = 10;
        const newTextDelay = 100; // Delay between current and next text
        let textArrayIndex = 0;
        let charIndex = 0;

        function type() {
            if (charIndex < textArray[textArrayIndex].length) {
                if (!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
                typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
                charIndex++;
                setTimeout(type, typingDelay);
            } else {
                cursorSpan.classList.remove("typing");
                setTimeout(erase, newTextDelay);
            }
        }

        function erase() {
            if (charIndex > 0) {
                // add class 'typing' if there's none
                if (!cursorSpan.classList.contains("typing")) {
                    cursorSpan.classList.add("typing");
                }
                typedTextSpan.textContent = textArray[textArrayIndex].substring(0, 0);
                charIndex--;
                setTimeout(erase, erasingDelay);
            } else {
                cursorSpan.classList.remove("typing");
                textArrayIndex++;
                if (textArrayIndex >= textArray.length) textArrayIndex = 0;
                setTimeout(type, typingDelay);
            }
        }

        document.addEventListener("DOMContentLoaded", function () { // On DOM Load initiate the effect
            if (textArray.length) setTimeout(type, newTextDelay + 250);
        });

    </script>
    <!-- //typig-text-->

    <!-- services owlcarousel -->
    <script src="<?php echo e(asset('js/owl.carousel.js')); ?>"></script>

    <!-- script for services -->
    <script>
        $(document).ready(function () {
            $('.owl-two').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                responsiveClass: true,
                autoplay: false,
                autoplayTimeout: 5000,
                autoplaySpeed: 1000,
                autoplayHoverPause: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    480: {
                        items: 1,
                        nav: false
                    },
                    700: {
                        items: 1,
                        nav: false
                    },
                    1090: {
                        items: 3,
                        nav: false
                    }
                }
            })
        })

    </script>
    <!-- //script for services -->

    <!-- script for tesimonials carousel slider -->
    <script>
        $(document).ready(function () {
            $("#owl-demo1").owlCarousel({
                loop: true,
                margin: 20,
                nav: false,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    736: {
                        items: 1,
                        nav: false
                    },
                    1000: {
                        items: 2,
                        nav: false,
                        loop: false
                    }
                }
            })
        })

    </script>
    <!-- //script for tesimonials carousel slider -->

    <!-- video popup -->
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.popup-with-zoom-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });

            $('.popup-with-move-anim').magnificPopup({
                type: 'inline',

                fixedContentPos: false,
                fixedBgPos: true,

                overflowY: 'auto',

                closeBtnInside: true,
                preloader: false,

                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-slide-bottom'
            });
        });

    </script>
    <!-- //video popup -->

    <!-- stats number counter-->
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.countup.js')); ?>"></script>
    <script>
        $('.counter').countUp();

    </script>
    <!-- //stats number counter -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });

    </script>
    <!-- disable body scroll which navbar is in active -->

    <!--/MENU-JS-->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });

    </script>
    <!--//MENU-JS-->

    <!-- bootstrap js -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>


</body>

</html>
<?php /**PATH /Users/faiz/Documents/kodein-bootcamp/kodein/resources/views/welcome.blade.php ENDPATH**/ ?>